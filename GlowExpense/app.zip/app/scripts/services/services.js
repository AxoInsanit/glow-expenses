'use strict';

angular.module('Services', [])
    .config(function () {})
    .constant('editModeToggled', 'TOGGLE_EDIT_MODE');
