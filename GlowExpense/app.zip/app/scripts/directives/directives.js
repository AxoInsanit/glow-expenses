'use strict';

angular.module('Directives', [])
    .config(function () {});