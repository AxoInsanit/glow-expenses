'use strict';

angular.module('Directives', [])
    .config(function () {})
    .constant('expensesListTemplateUrl', 'scripts/directives/views/expenses-list.html')
    .constant('editExpenseTemplateUrl', 'scripts/directives/views/edit-expense.html');
