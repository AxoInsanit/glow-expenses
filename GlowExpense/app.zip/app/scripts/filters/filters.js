'use strict';

angular.module('Filters', [])
    .config(function () {});