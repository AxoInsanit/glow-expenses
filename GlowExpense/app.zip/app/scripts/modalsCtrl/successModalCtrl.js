// 'use strict';

// var successModalCtrl = function ($scope, $modalInstance, data) {

// 	$scope.saveEditTitle = data.expenses.description;
// 	$scope.text = '';
// };