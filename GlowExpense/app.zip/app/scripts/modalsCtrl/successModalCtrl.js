var successModalCtrl = function ($scope, $modalInstance, data, $location) {

	$scope.saveEditTitle = data.expenses.description;		
	$scope.text = "";
};