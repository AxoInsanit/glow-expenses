'use strict';

angular.module('Reports', [])
    .config(function () {})
    .constant('addReportErrorMsg','Please complete all fields!')
    .constant('entityName','Report')
    .constant('reportDetailsPath','/report-details')
    .constant('editExpensePath','/edit-expense');




