'use strict';

angular.module('Reports')
    .controller('ViewReportCtrl', ['$scope', '$filter', '$location', 'addReportErrorMsg', '$modal',
        function ($scope, $filter, $location, addReportErrorMsg, $modal)  {
        	//debugger;
            $scope.errorMessage = addReportErrorMsg;
            $scope.showErrorMessage = false;

            $scope.createExpense = function() {
             	$location.path('/add-expense');
            };
            $scope.addOrEdit = function() {
             	var modalInstance = $modal.open({
                  templateUrl: 'createModal',
                  controller: expenseTypeModalCtrl,
                  resolve: {
                    expenseTypes: function () {
                      return {"types": $scope.expenseTypes,"target":event.target};
                    }
                  }
                });
            };
        }
    ]);