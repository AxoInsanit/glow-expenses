/* jshint quotmark:true, indent:false, white: false */
"use strict";

 angular.module("AppConfig", [])

.constant("foo", "stagingFoo")

;