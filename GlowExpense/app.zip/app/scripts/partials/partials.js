'use strict';

angular.module('Partials', [])
    .config(function () {});



