'use strict';

angular.module('InvoiceExpenseImage', [])
    .config(function () {});



