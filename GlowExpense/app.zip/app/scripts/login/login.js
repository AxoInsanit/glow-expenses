'use strict';

angular.module('Login', ['ngResource'])
    .config(function () {})
    .constant('errorMsg', 'Please try again! Username or password is wrong!');
    
