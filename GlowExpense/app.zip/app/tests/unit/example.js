'use strict';
describe('Example', function() {
    it('should have a message equal to "Hello!"', function() {
        expect('Hello!').toBe('Hello!');
    });
});