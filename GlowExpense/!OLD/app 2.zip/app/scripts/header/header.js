'use strict';

angular.module('Header', [])
    .config(function () {})
    .constant('loginPath', '/login');
    

