'use strict';

angular.module('Modals', [])
    .config(function () {});
    

